//
//  NuclearView.swift
//  NuclearBombSimulation
//
//  Created by Whit Castiglioni on 4/25/21.
//

import Foundation

import Foundation
import SwiftUI
import CorePlot

struct NuclearView: View {
    var functionSelect = ["No Plot Selected", "plot critical radius (Inputs: Ratio)", "plot crit radius vs ratio", "plot efficiency (Inputs: Ratio)"]
    @State private var selectedPlotIndex = 0

    
    var coreSelect = ["U-235", "Pu-239"]
    @State private var selectedCoreIndex = 0
    
    var tamperSelect = ["Tungsten Carbine", "Lead", "Depleted Uranium", "Beryllium Oxide" , "Aluminum"]
    @State private var selectedTamperIndex = 0
    
    
    @ObservedObject private var NukeCalculator = NuclearCalculations()
    @EnvironmentObject var plotDataModel :PlotDataClass

    @State var ratioOfRTampAndRCoreString = "1.2"
    @State var numberOfCriticalMassesString = "1.5"
   
    //R_bareCriticalityText
    //M_bareCriticalityText
    //R_tampedCriticalityText
    //M_tampedCriticalityText
    
    @State var RBareString = ""
    @State var MBareString = ""
    @State var RTampString = ""
    @State var MTampString = ""
    @State var yieldString = ""
    @State var efficiencyOfBombString = ""
    
    @State var plotSelect = 1
    var body: some View {
        HStack{
            
            CorePlot(dataForPlot: $plotDataModel.plotData, changingPlotParameters: $plotDataModel.changingPlotParameters)
                .setPlotPadding(left: 10)
                .setPlotPadding(right: 10)
                .setPlotPadding(top: 10)
                .setPlotPadding(bottom: 10)
                .padding()
            VStack{
                HStack{
                    VStack{
                        Text("Core Select:")
                            .font(.callout)
                            .bold()
                        Picker(selection: $selectedCoreIndex, label: Text("")) {
                                ForEach(0 ..< coreSelect.count) {
                                   Text(self.coreSelect[$0])
                                }
                        }
                    }
                    VStack{
                        Text("Tamper Select:")
                            .font(.callout)
                            .bold()
                        Picker(selection: $selectedTamperIndex, label: Text("")) {
                                ForEach(0 ..< tamperSelect.count) {
                                   Text(self.tamperSelect[$0])
                                }
                        }
                    }
                }
                VStack(alignment: .center) {
                    HStack{
                        Text("Radius of core(cm):")
                            .font(.callout)
                            .bold()
                        TextField("Radius(cm):", text: $RBareString)
                            .padding()
                    }
                    HStack{
                        Text("Mass of bare core(Kg):")
                            .font(.callout)
                            .bold()
                        TextField("Mass of bare core(Kg):", text: $MBareString)
                            .padding()
                    }
                    HStack{
                        Text("Radius of tamper(cm):")
                            .font(.callout)
                            .bold()
                        TextField("Radius of tamper:", text: $RTampString)
                            .padding()
                    }

                    HStack{
                        Text("Mass of tamper core(Kg):")
                            .font(.callout)
                            .bold()
                        TextField("Mass of bare core(Kg):", text: $MTampString)
                            .padding()
                    }
                    HStack{
                        Text("Yield:")
                            .font(.callout)
                            .bold()
                        TextField("Mass of bare core(TNT ton):", text: $yieldString)
                            .padding()

                    }
                    HStack{
                        Text("Efficiency:")
                            .font(.callout)
                            .bold()
                        TextField("efficiency:", text: $efficiencyOfBombString)
                            .padding()
                    }
                    HStack{
                        Text("Inputs:")
                        HStack(alignment: .center){
                            Text("Ratio of R tampered to R core ")
                                .font(.callout)
                                .bold()
                            TextField("ratio", text: $ratioOfRTampAndRCoreString)
                                .padding()

                        }
                        HStack{
                            Text("Number of critical masses")
                                .font(.callout)
                                .bold()
                            TextField("Number of masses", text: $numberOfCriticalMassesString)
                                .padding()
                            
                        }

                    }
//                    TextField("# Guesses", text: $guessString)
//                        .padding()
                }
                .padding(.top, 5.0)
              
                Button("Cycle Calculation", action: {self.calculateNuke() })
                    .padding()
                Picker(selection: $selectedPlotIndex, label: Text("")) {
                        ForEach(0 ..< functionSelect.count) {
                           Text(self.functionSelect[$0])
                        }
                }
//
//                Button("Clear", action: {self.clear()})
//                    .padding(.bottom, 5.0)
                
                
            }
            .padding()
            
            //DrawingField
            

            // Stop the window shrinking to zero.
            Spacer()
            
        }
    }
    func calculateNuke() {
        //NukeCalculator.plotDataModel = self.plotDataModel
        NukeCalculator.plotDataModel = self.plotDataModel
        plotSelect = selectedPlotIndex
        NukeCalculator.plotPicker = plotSelect
        NukeCalculator.corePicker = selectedCoreIndex
        NukeCalculator.tamperPicker = selectedTamperIndex
        if NukeCalculator.dataOverride == -1 {
            let ratioOfRTampAndRCore = Double(ratioOfRTampAndRCoreString) ?? Double(0.0)
            let numberOfCritMasses = Double(numberOfCriticalMassesString) ?? Double(0.0)
            NukeCalculator.numberOfCriticalMasses = numberOfCritMasses
            NukeCalculator.ratio = ratioOfRTampAndRCore
            NukeCalculator.calculateNuclearProgram()
            RBareString = NukeCalculator.R_bareCriticalityText
            MBareString = NukeCalculator.M_bareCriticalityText
            RTampString = NukeCalculator.R_tampedCriticalityText
            MTampString = NukeCalculator.M_tampedCriticalityText
            yieldString = NukeCalculator.yieldInktTNTString
            efficiencyOfBombString = NukeCalculator.efficiencyString
        }

    }

    func plotCritRadiusFunctional(){
        NukeCalculator.plotDataModel = self.plotDataModel
        plotSelect = 1
        NukeCalculator.plotPicker = plotSelect
    }
    
}

struct NuclearView_Previews: PreviewProvider {
    static var previews: some View {
        NuclearView()
    }
}
 
//pass the plotDataModel to the cosCalculator
//calculator.plotDataModel = self.plotDataModel


