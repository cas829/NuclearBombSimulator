//
//  NuclearBombSimulationApp.swift
//  Shared
//
//  Created by Whit Castiglioni on 4/23/21.
//

import SwiftUI
import CorePlot

@main
struct NuclearBombSimulationApp: App {
        
    @StateObject var plotDataModel = PlotDataClass(fromLine: true)
        
    var body: some Scene {
        WindowGroup {
            TabView {
                NuclearView()
                    .environmentObject(plotDataModel)
                    .tabItem {
                        Text("Plot")
                    }
            }
                
        }
    }
}
