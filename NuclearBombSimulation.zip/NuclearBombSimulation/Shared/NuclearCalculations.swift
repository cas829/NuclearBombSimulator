//
//  NuclearCalculations.swift
//  NuclearBombSimulation
//
//  Created by Whit Castiglioni on 4/23/21.
//

import Foundation
import SwiftUI
import CorePlot

//var plotDataModel: PlotDataClass? = nil

class NuclearCalculations: NSObject, ObservableObject {
    
    var plotDataModel: PlotDataClass? = nil
    //the picker's chose what type of core or tamper is used for the calculations
    @Published var plotPicker = -1
    @Published var dataOverride = -1
    
    @Published var corePicker = 0
    @Published var tamperPicker = 0
    
    @Published var ratio = 2.23 //ratio means the ratio of the tamper radius to core radius
    //parramiters are defulted to U-235
    @Published var v_numberOfNeutronsRelease = 2.637 //number of neutrons emmited from a fission. defulted to U-235 value
    @Published var tau = 8.635 //units 10^(-9) sec
    @Published var R_bareCriticality = 8.37 // radius for bare core threshhold criticality //units cm
    @Published var R_bareCriticalityText = ""
    @Published var M_bareCriticality = 45.9 // mass for bare core threshhold criticality //units kg
    @Published var M_bareCriticalityText = ""

    @Published var nuclearNumberDensity = 4.794 // units 10^22 cm^(-3)
    @Published var d_core = 3.53
    
    
    @Published var R_tampedCriticality = 8.37 // outer radius for tamper at threshhold criticality //units cm
    @Published var R_tampedCriticalityText = ""
    @Published var M_tampedCriticality = 45.9 // mass for tamper at threshhold criticality //units kg
    @Published var M_tampedCriticalityText = ""
    @Published var numberOfCriticalMasses = 2.5296//2.878 //value is defalted around little boy value
    //@Published var tamperMeanFreePath = 4.0 // units cm // this is a guess and will be calculated
    
    @Published var threshhold = 0.000001

    
    //sterp size can be relitively large if the risk of a sign switch that is rappied is not present
    @Published var stepSize = 0.5
    
    @Published var loopingLimit = 20000000
    


    //for core fissile masteril
    @Published var densityCore = 18.72 //density of fission full //units gr/cm^3
    @Published var crossSectionFissionCore = 1.235 //units bn
    @Published var crossSectionElasticScatterCore = 4.566 //units bn
    @Published var atomicMassCore = 235.043 //units g/mol


    //for tamper material
    @Published var densityTamper = 15.63//18.71 //density of fission full //units gr/cm^3
    @Published var crossSectionFissionTamper = 0.0 //units bn
    @Published var crossSectionElasticScatterTamper = 6.587 //units bn
    @Published var atomicMassTamper = 195.85 //units g/mol
   
    @Published var energyPerFission = 180.9 //MeV // sume of kenetic energy of fragments, neutron kenetic energys, and prompt gamma rays
    @Published var MeVToJoule = 1.6022e-13
    
    @Published var yield = 0.0
    @Published var yieldInktTNT = 0.0
    @Published var jouleToTNTTon = 2.39006e-10
    @Published var yieldInktTNTString = ""
    
    @Published var efficiency = 0.0
    @Published var efficiencyString = ""
    /*specicale cases
    specicale cases of transport cross sections that are known mesured values will
     bypass the calculations for the transport mean free path and use the known values
     values are soureced from the book "The Physics of the Manhattan Project"(third edition)(by Bruce Cameron Reed)
     
     all transport crosssections are in cm
     commented next to the diffrent lambdas are "SC" standing for specical case
     specical case is a varible accepted by the
    */
    @Published var lambdaTransportCalculatedCore = -1.0   //SC:0
    @Published var lambdaTransportCalculatedTamper = -1.0 //SC:1
    @Published var lambdaTansportU235 = 3.6               //SC:2
    @Published var lambdaTansportPu239 = 4.11             //SC:3
    

    @Published var lambdaFissionCore = -1.0
    @Published var specicalCaseLambdaCore = 2 //defulted to U235
    @Published var specicalCaseLambdaTamp = 4 //defulted to core lambda
    
    
    var plotData :[plotDataType] =  []


    func calculateEnergyParameters() {
        //first section will calculate yield
        //numberOfCriticalMasses = 64.0 / M_bareCriticality
        let massOfCore = numberOfCriticalMasses * M_bareCriticality
        let RInitalInCm = calculateRadiusFromMassAndDensity(density: densityCore, mass: massOfCore)
        let RTamper = ratio * RInitalInCm
        let massOfTamper = calculateMassGeneralized(density: densityTamper, outerRadius: RTamper, inerRadius: RInitalInCm)
        let totalMass = massOfTamper + massOfCore
        let deltaRInCm = RInitalInCm - R_bareCriticality
        let deltaR = deltaRInCm / 100.0

        //     M(total)  (  ∆R ln(v)    )^2
        // Y ~ -------   | ------------ |
        //       8       (      tau     )
        //       ^ term 1       ^ term 2
        let term1 = totalMass / 8.0
        let term2Log = log(v_numberOfNeutronsRelease)
        let term2Numerator = deltaR * term2Log
        let tempTau = tau * 1.0e-9
        let term2pt1 = term2Numerator / tempTau
        let term2pt2 = term2pt1 //* 1.0e9 // this is to account for the fact that tau is 10^(-9)s for units
        let term2 = pow(term2pt2, 2.0)
        let calcYield = term1 * term2
        yield = calcYield
        yieldInktTNT = calcYield * jouleToTNTTon / 1000.0
        yieldInktTNTString = String(yieldInktTNT)
        let energyRelesedPerFission = energyPerFission * MeVToJoule
        let n_numerator = densityCore * 6.02214076e23
        let n = n_numerator / atomicMassCore
        let volumeNumerator = 4.0 * Double.pi * pow(RInitalInCm, 3.0)
        let volume = volumeNumerator / 3.0
        let efficiencyDenominator = n * volume * energyRelesedPerFission
        efficiency = yield / efficiencyDenominator
        efficiencyString = String(efficiency)
        
    }
    func calculateCriticalRadiiGeneralized(ratio: Double){
        if plotPicker == 1 {
            plotDataModel!.changingPlotParameters.yMax = 3.25
            plotDataModel!.changingPlotParameters.yMin = -3.25
            plotDataModel!.changingPlotParameters.xMax = 10.5
            plotDataModel!.changingPlotParameters.xMin = -0.75
            plotDataModel!.changingPlotParameters.xLabel = "Critical Radius(cm)"
            plotDataModel!.changingPlotParameters.yLabel = "Functional"
            plotDataModel!.changingPlotParameters.lineColor = .red()
            plotDataModel!.changingPlotParameters.title = " Critical Radius"
            
            plotDataModel!.zeroData()
            //var plotData :[plotDataType] =  []
        }

        var R_guess = 0.000513
        var threshholdKillSwitch = true
        var loopCount = 0
        var sameAsInitalSign = true
        //let inverseRatio = 1.0 / ratio
        var initalSignTracker = 0
        // ratio = R(tamp)/R(thresh/core)
        //this equation assumes a alpha = 0
        //    TERM 1
        // __                                  __
        // |  1 + 2 λ(tamp)               1     |
        // |      ------------------  - ------  |
        // --     3 (Ratio)*R(tamp)     Ratio  --
        
        //    TERM 2
        //   __                                      __
        //  |    R(tamp)          R(tamp)              |
        //  |    --------    cot( ------------- )  - 1 |
        //  --  d(core)*ratio     d(core)*Ratio      --
        
        //    TERM 3
        //    λ(tamp)/λ(core)
        // (TERM 1)*(TERM 2) + (TERM 3) = 0
        

        //calculate transport mean free path of core and tamper
        calculatetTransportLambda(specialCaseIndex: specicalCaseLambdaCore)
        calculatetTransportLambda(specialCaseIndex: specicalCaseLambdaTamp)
        lambdaFissionCore = calculateLambdaEquation(crossSectionF: crossSectionFissionCore, CrossSectionEl: 0.0, density: densityCore, atomicMassNumber: atomicMassCore)
        checkLambdaErrors()

        calculateDCore(alpha: 0.0)

        //this loops calculates the equation above
        //the solution is calculated step by step untill the sign changes
        // once the sign changes it goes back 2 steps and halfs the step size
        // untill the sloution calciualted is within the threshhold
        while (R_guess < 35.0) && threshholdKillSwitch && (loopCount < loopingLimit){
            let term1pt1Numerator = 2.0 * lambdaTransportCalculatedTamper
            let term1pt1Demnominator = 3.0 * ratio * R_guess
            let term1pt1 = term1pt1Numerator / term1pt1Demnominator
            let term1pt2 = 1.0 / ratio
            let term1 = 1.0 + term1pt1 - term1pt2
            
            let term2pt1Demnominator = ratio * d_core
            let term2pt1 = R_guess / term2pt1Demnominator
            let phaseDemominator = d_core * ratio
            let phase = R_guess / phaseDemominator
            let term2Trig = cos(phase) / sin(phase)
            let term2 = term2pt1*term2Trig - 1.0
            
            let term3 = lambdaTransportCalculatedTamper / lambdaTransportCalculatedCore
            
            let coreRadiusDepentEquation = term1 * term2 + term3


            if initalSignTracker == 0 {
                if coreRadiusDepentEquation < 0.0 {
                    initalSignTracker = -1
                }
                if coreRadiusDepentEquation > 0.0 {
                    initalSignTracker = 1
                }
            }
            //R_guess += stepSize
            
            //these if statments are active one the sign of the inital guess changes. one the sine hase changed they bring back the guess to a couple of guess ago and change the step size so it is smaller. this is repeated untill the disired threshhold is reached
            if coreRadiusDepentEquation < 0 && initalSignTracker == 1 {
                R_guess -= 2.0 * stepSize
                stepSize = stepSize / 2.0
                sameAsInitalSign = false
            }
            if coreRadiusDepentEquation > 0 && initalSignTracker == -1 {
                R_guess -= 2.0 * stepSize
                stepSize = stepSize / 2.0
                sameAsInitalSign = false
            }
            if abs(coreRadiusDepentEquation) < threshhold {
                threshholdKillSwitch = false
                if plotPicker == 1 {
                    let RCorePlotInput = R_guess / ratio
                    let dataPoint: plotDataType = [.X: RCorePlotInput, .Y: coreRadiusDepentEquation]
                    plotData.append(contentsOf: [dataPoint])
                }

            }
            if plotPicker == 1 {
                if sameAsInitalSign {
                    let RCorePlotInput = R_guess / ratio
                    let dataPoint: plotDataType = [.X: RCorePlotInput, .Y: coreRadiusDepentEquation]
                    plotData.append(contentsOf: [dataPoint])
                }
            }
            //updates tamper radius to next step
            R_guess += stepSize

            loopCount += 1
        }
        if !(loopCount < loopingLimit) {
            print("interations are above limmit")
        }
        if plotPicker == 1 {
            plotDataModel!.appendData(dataPoint: plotData)

        }

        R_tampedCriticality = R_guess
        R_tampedCriticalityText = String(R_guess)
        let radiusThreshCore = R_tampedCriticality / ratio
        R_bareCriticality = radiusThreshCore
        R_bareCriticalityText = String(radiusThreshCore)
        calculateMassBare()
        calculateMassTamper()
        resetTriggers()

    }
    func calculateMassTamper(){
        let differenceOfCubedRadii = pow(R_tampedCriticality, 3.0) - pow(R_bareCriticality, 3.0)
        let volumeNumerator = 4.0 * Double.pi * differenceOfCubedRadii
        let volume = volumeNumerator / 3.0
        let mass = volume * densityTamper * 0.001 // the 0.001 changes grams to kg
        M_tampedCriticality = mass
        M_tampedCriticalityText = String(mass)
    }
    func calculateDCore(alpha: Double){
        let lambdaProduct = lambdaFissionCore * lambdaTransportCalculatedCore
        let denominator = 3 * (v_numberOfNeutronsRelease - 1.0 - alpha)
        let radical = lambdaProduct/denominator
        let calculatedDCore = radical.squareRoot()
        d_core = calculatedDCore
    }
    func calculateMassBare(){
        let volumeNumerator = 4.0 * Double.pi * pow(R_bareCriticality, 3.0)
        let volume = volumeNumerator / 3.0
        let mass = volume * densityCore * 0.001
        M_bareCriticality = mass
        M_bareCriticalityText = String(mass)
    }
    func calculateRadiusFromMassAndDensity(density: Double, mass: Double) -> Double {
        let massInGrams = mass * 1000.0
        let rCubedNumerator = 3.0 * massInGrams
        let rCubedDenominator = 4.0 * Double.pi * density
        let rCubed = rCubedNumerator / rCubedDenominator
        let radius = pow(rCubed, (1.0/3.0))
        return radius
    }

    
    func calculateMassGeneralized(density: Double, outerRadius: Double, inerRadius: Double)-> Double{//output in kg
        let cubedDifference = pow(outerRadius, 3.0) - pow(inerRadius, 3.0)
        let volumeNumerator = 4.0 * Double.pi * cubedDifference
        let volume = volumeNumerator / 3.0
        let mass = volume * density * 0.001
        return mass
    }
    func resetTriggers() { //reset varibles that need to be reset by programs after they run to function properaly
        stepSize = 0.5
    }
    func parameterSelect() {
    
        switch corePicker {
        case 0: //U-235
            densityCore = 18.72 //density of fission full //units gr/cm^3
            crossSectionFissionCore = 1.235 //units bn
            crossSectionElasticScatterCore = 4.566 //units bn
            atomicMassCore = 235.043 //units g/mol
            v_numberOfNeutronsRelease = 2.637
            tau = 8.635
            energyPerFission = 180.9
        case 1: //Pu-239
            densityCore = 15.6 //density of fission full //units gr/cm^3
            crossSectionFissionCore = 1.800 //units bn
            crossSectionElasticScatterCore = 4.394 //units bn
            atomicMassCore = 239.05 //units g/mol
            v_numberOfNeutronsRelease = 3.172
            tau = 7.227
            energyPerFission = 189.5
        default: //defalt to U-235
            densityCore = 18.72 //density of fission full //units gr/cm^3
            crossSectionFissionCore = 1.235 //units bn
            crossSectionElasticScatterCore = 4.566 //units bn
            atomicMassCore = 235.043 //units g/mol
            v_numberOfNeutronsRelease = 2.637
            tau = 8.635
            energyPerFission = 180.9
        }
        
        //tamper parameters
        switch tamperPicker {
        case 0: //Tungsten Carbine
            atomicMassTamper = 195.85 //units g/mol
            densityTamper = 15.63 //units gr/cm^3
            crossSectionElasticScatterTamper = 6.587 //units bn
        case 1: //Lead
            atomicMassTamper = 207.85 //units g/mol
            densityTamper = 11.35 //units gr/cm^3
            crossSectionElasticScatterTamper = 5.587 //units bn
        case 2: //Depleted Uranium
            atomicMassTamper = 238.05 //units g/mol
            densityTamper = 18.95 //units gr/cm^3
            crossSectionElasticScatterTamper = 4.804 //units bn
        case 3: //Beryllium Oxide
            atomicMassTamper = 25.01 //units g/mol
            densityTamper = 3.02 //units gr/cm^3
            crossSectionElasticScatterTamper = 5.412 //units bn
        case 4: //Aluminum
            atomicMassTamper = 26.982 //units g/mol
            densityTamper = 2.699 //units gr/cm^3
            crossSectionElasticScatterTamper = 2.967 //units bn
        default: //defalt to Tungsten Carbine
            atomicMassTamper = 195.85 //units g/mol
            densityTamper = 15.63 //units gr/cm^3
            crossSectionElasticScatterTamper = 6.587 //units bn
        }
        
    }
    func calculateNuclearProgram(){
        //calculateCriticalRadius()
        //let ratioInput = M_tampedCriticality
        parameterSelect()
        calculateCriticalRadiiGeneralized(ratio: ratio)
        calculateEnergyParameters()
        critCoreRadiusVsTampCoreRadius()
        
        effiencyVsCoreRadius()

    }
    //calculates transport mean free paths of core or tamper
    func calculatetTransportLambda(specialCaseIndex: Int){
        
        let coreLambda = calculateLambdaEquation(crossSectionF: crossSectionFissionCore, CrossSectionEl: crossSectionElasticScatterCore, density: densityCore, atomicMassNumber: atomicMassCore)
        lambdaTransportCalculatedCore = coreLambda
        
        let tamperLambda = calculateLambdaEquation(crossSectionF: crossSectionFissionTamper, CrossSectionEl: crossSectionElasticScatterTamper, density: densityTamper, atomicMassNumber: atomicMassTamper)
        lambdaTransportCalculatedTamper = tamperLambda
    }
    func calculateLambdaEquation(crossSectionF: Double, CrossSectionEl: Double, density: Double ,atomicMassNumber: Double) -> Double{
        // have code that takes dencty, atomic number, and cross-sections(fission and elastic) and spits out a lamdba
        //equation used for lambda simplifiyed to give cm from input parameters
        //  10 * (atomic mass number (amu))
        // ------------------------------------------------------ = mean free path(cm)
        // (cross section (bn)) * (dencity (g/cm^3)) * 6.0221409
        let lambdaNumerator = 10.0 * atomicMassNumber
        let meanFreePathSum = crossSectionF + CrossSectionEl
        let lambdaDenominator = meanFreePathSum * density * 6.0221409
        let meanFreePath = lambdaNumerator / lambdaDenominator
        return meanFreePath
    }
    func critCoreRadiusVsTampCoreRadius() {
        if plotPicker == 2 {
            dataOverride = 1
            plotDataModel!.changingPlotParameters.yMax = 10.0
            plotDataModel!.changingPlotParameters.yMin = -3.25
            plotDataModel!.changingPlotParameters.xMax = 4.5
            plotDataModel!.changingPlotParameters.xMin = -0.75
            plotDataModel!.changingPlotParameters.xLabel = "Ratio of tamped radius to core radius"
            plotDataModel!.changingPlotParameters.yLabel = "core Radius"
            plotDataModel!.changingPlotParameters.lineColor = .red()
            plotDataModel!.changingPlotParameters.title = " Critical Radius Ratio"
            
            plotDataModel!.zeroData()
            var plotData :[plotDataType] =  []
            
            var tamperRatio = 1.0
            while tamperRatio < 3.0 {
                calculateCriticalRadiiGeneralized(ratio: tamperRatio)
                let tempCoreRadius = R_bareCriticality
                let dataPoint: plotDataType = [.X: tamperRatio, .Y: tempCoreRadius]
                plotData.append(contentsOf: [dataPoint])
                tamperRatio += 0.1
            }
            plotDataModel!.appendData(dataPoint: plotData)
        }
        else{
            dataOverride = -1
        }
    }
    //plot's effiency of bomb, takes critical radius and goes 2.5 critical masses more
    func effiencyVsCoreRadius()  {
        if plotPicker == 3 {
            dataOverride = 1
            plotDataModel!.changingPlotParameters.yMax = 0.1
            plotDataModel!.changingPlotParameters.yMin = -0.024
            plotDataModel!.changingPlotParameters.xMax = 11.0
            plotDataModel!.changingPlotParameters.xMin = 6.0
            plotDataModel!.changingPlotParameters.xLabel = "Radius of tamped core(cm)"
            plotDataModel!.changingPlotParameters.yLabel = "efficiency"
            plotDataModel!.changingPlotParameters.lineColor = .red()
            plotDataModel!.changingPlotParameters.title = " Efficiency"
            
            plotDataModel!.zeroData()
            var plotData :[plotDataType] =  []
            var numberOfCritMassForLoop = 1.0
            while numberOfCritMassForLoop < 2.5 {
                numberOfCriticalMasses = numberOfCritMassForLoop
                calculateEnergyParameters()

                let massOfCore = numberOfCritMassForLoop * M_bareCriticality
                calculateEnergyParameters()
                let tempCoreRadius = calculateRadiusFromMassAndDensity(density: densityCore, mass: massOfCore)
                let tempEff = efficiency
                let dataPoint: plotDataType = [.X: tempCoreRadius, .Y: tempEff]
                plotData.append(contentsOf: [dataPoint])
                numberOfCritMassForLoop += 0.1
            }
            plotDataModel!.appendData(dataPoint: plotData)
        }
        else{
            dataOverride = -1
        }
    }
    func checkLambdaErrors(){
        if lambdaTransportCalculatedCore < 0.0  {
            print("Error in core tans lambda " + String(lambdaTransportCalculatedCore))
        }
        if lambdaTransportCalculatedTamper < 0.0  {
            print("Error in tamper tans lambda " + String(lambdaTransportCalculatedTamper))
        }
        if lambdaFissionCore < 0.0 {
            print("Error in core Fission lambda " + String(lambdaFissionCore))
        }
    }
}

