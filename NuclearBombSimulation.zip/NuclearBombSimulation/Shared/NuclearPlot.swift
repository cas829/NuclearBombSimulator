//
//  NuclearPlot.swift
//  NuclearBombSimulation
//
//  Created by Whit Castiglioni on 5/7/21.
//


import Foundation
import SwiftUI
import CorePlot

struct NuclearPlot: View {
    @ObservedObject private var NukeCalculator = NuclearCalculations()
    @EnvironmentObject var plotDataModel :PlotDataClass

    @State var ratioOfRTampAndRCoreString = "1.2"
    @State var numberOfCriticalMassesString = "1.5"
   
    var body: some View {
        HStack{
            
            CorePlot(dataForPlot: $plotDataModel.plotData, changingPlotParameters: $plotDataModel.changingPlotParameters)
                .setPlotPadding(left: 10)
                .setPlotPadding(right: 10)
                .setPlotPadding(top: 10)
                .setPlotPadding(bottom: 10)
                .padding()
            VStack{
                
                VStack(alignment: .center) {
                    HStack{
                        Text("Radius of core(cm):")
                            .font(.callout)
                            .bold()
                        TextField("Radius of core(cm)", text: $NukeCalculator.R_bareCriticalityText)
                            .padding()
                    }
                    HStack{
                        Text("Mass of bare core(g):")
                            .font(.callout)
                            .bold()
                        TextField("Mass of bare core(g):", text: $NukeCalculator.M_bareCriticalityText)
                            .padding()
                    }
                    HStack{
                        Text("Radius of tamper(cm):")
                            .font(.callout)
                            .bold()
                        TextField("Radius of tamper:", text: $NukeCalculator.R_tampedCriticalityText)
                            .padding()
                    }

                    HStack{
                        Text("Mass of tamper core(g):")
                            .font(.callout)
                            .bold()
                        TextField("Mass of bare core(g):", text: $NukeCalculator.M_tampedCriticalityText)
                            .padding()
                    }
                    HStack{
                        Text("Yield:")
                            .font(.callout)
                            .bold()
                        TextField("Mass of bare core(TNT ton):", text: $NukeCalculator.yieldInktTNTString)
                            .padding()
                    }
                    HStack{
                        Text("Efficiency:")
                            .font(.callout)
                            .bold()
                        TextField("Efficiency:", text: $NukeCalculator.efficiencyString)
                            .padding()
                    }
                    HStack{
                        Text("Inputs")
                        HStack(alignment: .center){
                            Text("ratio of R tampered to R core ")
                                .font(.callout)
                                .bold()
                            TextField("ratio", text: $ratioOfRTampAndRCoreString)
                                .padding()
                        }
                        HStack{
                            Text("number of critical masses")
                                .font(.callout)
                                .bold()
                            TextField("Number of masses", text: $numberOfCriticalMassesString)
                                .padding()
                            
                        }

                    }
//                    TextField("# Guesses", text: $guessString)
//                        .padding()
                }
                .padding(.top, 5.0)
              
                Button("Cycle Calculation", action: {self.calculateNuke() })
                    .padding()
//
//                Button("Clear", action: {self.clear()})
//                    .padding(.bottom, 5.0)
                
                
            }
            .padding()
            
            //DrawingField
            

            // Stop the window shrinking to zero.
            Spacer()
            
        }
    }
    func calculateNuke() {
//        NukeCalculator.plotDataModel = self.plotDataModel
        
        let ratioOfRTampAndRCore = Double(ratioOfRTampAndRCoreString) ?? Double(0.0)
        let numberOfCritMasses = Double(numberOfCriticalMassesString) ?? Double(0.0)
        NukeCalculator.numberOfCriticalMasses = numberOfCritMasses
        NukeCalculator.ratio = ratioOfRTampAndRCore
        NukeCalculator.calculateNuclearProgram()
    }
    
}

struct NuclearPlot_Previews: PreviewProvider {
    static var previews: some View {
        NuclearPlot()
    }
}
 
//pass the plotDataModel to the cosCalculator
//calculator.plotDataModel = self.plotDataModel


